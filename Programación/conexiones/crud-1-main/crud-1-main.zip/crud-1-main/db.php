<?php

session_start();

$conn = mysqli_connect(
    'localhost',
    'root',
    '',
    'crud1'
);

// if (isset($conn)){
//     echo 'La DB está conectada';
// }

?>